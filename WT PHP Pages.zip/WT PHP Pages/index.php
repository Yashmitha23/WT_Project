<!DOCTYPE html>
<html>

<head>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>
        HOME PAGE-ALUMNI
    </title>
    <link rel="stylesheet" href="homepage2.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700;900&display=swap" rel="stylesheet">
    <link href="https://db.onlinewebfonts.com/c/10d0b50da141372ab1f5ae8af6193f9e?family=Glosa+W01+Black" rel="stylesheet">
</head>

<body>
        <header>
            <img src="./images/hglogo1.png">
            <h2>Welcome to Hogwart's Alumni Network</h2>
            <div class="container">
                <nav>
                    <ul>
                        <li><a href="login.php">LOGIN/REGISTER</a></li>
                    </ul>
                </nav>
            </div>
        </header>
        <div class="container1">
            <div class="box">
            <img src="./images/Screenshot (110).png" alt="Person">
              <p>"Rediscover the bonds of the past at our unforgettable reunion meet. Join us for a nostalgic journey and create new memories together!"</p>
              <p>"Come & feel the extravaganza"</p>
              <button class="btn">Know about it</button>
            </div>
          </div>
          <div class="container2">
            <h2 class="stories-title">Stories</h2>
            <div class="stories-container">
              <div class="story-box">
                <img src="./images/Screenshot 2023-08-29 064134.png" alt="Story 1">
                <h3>Message From Board To The Alumni</h3>
                <p>Read it,Know it and Cherish.</p>
              </div>
              <div class="story-box">
                <img src="./images/Screenshot 2023-08-29 064349.png" alt="Story 2">
                <h3>Me,Myself and AI</h3>
                <p>AI has entered a new era. Here's how we stay Human</p>
              </div>
              <div class="story-box">
                <img src="./images/pexels-nataliya-vaitkevich-6532373.jpg" alt="Story 3">
                <h3>Celebrating Achievements</h3>
                <p>Share your successes and hear about the accomplishments of others.</p>
              </div>
            </div>
            <a class="see-more1" href="#">See More &#8594;</a>
          </div>
          <div class="container3">
            <h2 class="benefits-title">Benefits</h2>
            <div class="benefits-container">
              <div class="benefit-box">
                <img src="./images/campusstore1.jpg" alt="Benefit 1">
                <h3>Discounts</h3>
                <p>Alumni Membership provides
                    <b>Discount</b> on Items that are available
                    in <b>Campus Store</b></p>
              </div>
              <div class="benefit-box">
                <img src="./images/scholarship1.jpg" alt="Benefit 2">
                <h3>Scholarships</h3>
                <p>Alumni Membership provides<b>Scholarship for Higher-Studies</b></p>
              </div>
              <div class="benefit-box">
                <img src="./images/investment1.webp" alt="Benefit 3">
                <h3>Investments</h3>
                <p>Exclusive Investment in Projects of alumni by Board of Directors<br>T&C APPLY*</p></p>
              </div>
            </div>
            <a class="see-more" href="#">See More &#8594;</a>
          </div>
          <div class="foot">
            <h1 style="text-align:center; font-size:40px;color:gray;">Hogwart's Alumni Association</h1>
            <h2 style="text-align:center; font-size:20px;color:whitesmoke;">With You in your Curriculum,</h2>
            <h2 style="text-align:center; font-size:20px;color:whitesmoke;">And With You Beyond your curriculum</h2>
            <h3 style="text-align:center; font-size: 18px;color:gray;">Stay in Touch</h3>
        <span>
            <span><p style="text-align:left; font-size:15px;color:gray;">Designed & Maintained by Batch-13 Sec III-C &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;
            &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;<a style="text-align:right; font-size:15px;color:gray;">&copy All Rights Reserved</a></p></span>
        </span>
    </div>
</body>
</html>