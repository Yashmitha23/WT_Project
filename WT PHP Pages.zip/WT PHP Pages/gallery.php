<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Image Upload</title>
  <link href="https://fonts.googleapis.com/css2?family=Material+Icons+Round" rel="stylesheet" />
    <link href="https://fonts.googleapis.com/css2?family=Material+Icons+Outlined" rel="stylesheet" />
  <style>
    body { 
        margin: 0px;
/*      font-family: Arial, sans-serif;*/
      /*background-image:url("pexels-athena-2983401 (2).jpg");*/
    }
    .foot {
        padding: 10px;
        background-color: black;
    }

    .navbar {
        background-color: #333;
        overflow: hidden;
        display: flex;
        align-items: center;
        justify-content: space-between;
        padding: 10px 20px;
        font-size: larger;
    }

    /* Style the logo */
    .logo img {
        height: 120px;
        width: 120px;
        object-fit: cover;
        border-radius: 50%;
    }

    /* Style the navigation links */
    .links ul {
        list-style: none;
        margin: 0;
        padding: 0;
        display: flex;
    }

    .links li {
        margin-right: 20px;
    }

    .links a {
        color: white;
        text-decoration: none;
        font-family: 'Roboto', sans-serif;
        font-weight: 500;
        transition: color 0.3s ease;
    }

    .links a:hover {
        color: #ddd;
    }

    /* Style the user icon and input */
    .text input[type="text"] {
        text-align: end;
        border: none;
        background-color: #333;
        padding: 8px;
        border-radius: 4px;
        color: white;
    }

    .text span {
        vertical-align: middle;
        margin-left: 10px;
        height: 20px;
        width: 20px;
        color: white;
    }

    /* Clear floats after the navigation bar */
    .navbar:after {
        content: "";
        display: table;
        clear: both;
    }
    form { 
      margin: 20px;
    }
    .uploaded-image {
  display: flex;
  flex-wrap: wrap;
}

.uploaded-image img {
  margin: 10px;
  margin-left: 50px;
  width: 400px; 
  height: 400px;
  object-fit: cover;
}
.image-wrap {
  display: inline-block;
  margin: 20px;
  width: 400px;
  text-align: center; 
}

.caption {
    text-align: center; 
  margin-top: 30px;
  font-size: x-large;
}
.image-wrap img {
  transition: transform .2s; /* Animation */
}

.image-wrap:hover img {
  transform: scale(1.3); /* Zoom out effect */ 
}
.image-gallery {
  border: 3px solid black;
  padding: 20px;
}
h2 {
  font-size: 2em; 
}

h3 {
  font-size: 1.5em;
  margin-bottom: 10px;
}

input[type="file"],
input[type="text"] {
  padding: 7px 25px;
  font-size: 1.2em;
}

input[type="submit"] {
  padding: 9px 30px;
  font-size: 1.2em;
  border-radius: 4px;
}
  </style>
</head>
<body>
    <div class="navbar">
                <div class="logo">
                    <a><img src="./images/hglogo1.png"></a>
                </div>
                <div class="links">
                    <nav>
                        <ul>
                        <li><a href="myhomepage.php">Home</a></li>
                        <li><a href="aboutus.php">About Us</a></li>
                        <li><a href="newsroom.php">News Room</a></li>
                        <li><a href="testimonals.php">Testimonals</a></li>
                        <li><a href="events.php">Events</a></li>
                        <li><a href="aldir.php">Alumni Directory/Connect</a></li>
                        <li><a href="gallery.php">Gallery</a></li>
                        </ul>
                    </nav>
                </div>
                <div class="text">
            <a><input type="text" id="profileField" name="username" style="font-size:large;" value="<?php session_start(); echo isset($_SESSION['username']) ? $_SESSION['username'] : 'My Profile';
            ?>" disabled>
            <span class="material-icons-outlined">
                account_circle
            </span>
            </a>
                    &emsp;&emsp;&emsp;&emsp;<a style="color: white;text-decoration: none;font-family: 'Roboto', sans-serif;font-weight: 500;transition: color 0.3s ease;"  href="index.php">Logout</a>
        </div>
            </div>
<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "demophp";

$conn = mysqli_connect($servername, $username, $password, $dbname);
if (!$conn) {
  die("Connection failed: " . mysqli_connect_error());
}

// Check if the form is submitted for events
if(isset($_POST['submitEvent'])){

  $eventImgFile = $_FILES['eventImage']['tmp_name'];
  $eventImgData = file_get_contents($eventImgFile);
  $eventCaption = $_POST['eventCaption'];
  $sql = "INSERT INTO events (event_caption, event_image) VALUES ('$eventCaption',?)";
  $stmt = mysqli_prepare($conn, $sql);
  mysqli_stmt_bind_param($stmt, 's', $eventImgData);
  if (mysqli_stmt_execute($stmt)) {
        echo '<script>alert("Inserted Successfully")</script>';
//         header("Location: index.php");
//      exit();
    }
     else{
            echo '<script>alert("There is an error");</script>';
        }
}

// Check if the form is submitted for official meets
if(isset($_POST['submitMeet'])){
    $meetImgFile = $_FILES['meetImage']['tmp_name'];
  $meetImgData = file_get_contents($meetImgFile);
  $meetCaption = $_POST['meetCaption'];
  $sql = "INSERT INTO official_meets (meet_caption, meet_image) VALUES ('$meetCaption',?)";
  $stmt = mysqli_prepare($conn, $sql);
  mysqli_stmt_bind_param($stmt, 's', $meetImgData);
  if (mysqli_stmt_execute($stmt)) {
        echo '<script>alert("Inserted Successfully")</script>';
    }
     else{
            echo '<script>alert("There is an error");</script>';
        }
}

?>
  <!-- ... (Other HTML content) -->

<h2>Events</h2>
<form action="#" method="post" enctype="multipart/form-data">
    <h3>Upload Event Image</h3>
    <input type="file" name="eventImage">
    <input type="text" name="eventCaption" placeholder="Enter Event Image Caption">
    <input type="submit" name="submitEvent" value="Upload">
  </form>
<div class="image-gallery">
<div class="uploaded-image">
  <?php
  // Retrieve and display the images and captions from the events table
  $resultEvents = mysqli_query($conn, "SELECT * FROM events");
  while ($row = mysqli_fetch_array($resultEvents)) {
      $imageData = $row['event_image'];
            $base64Image = base64_encode($imageData);
            echo '<div class="image-wrap">';
            echo '<img src="data:image/jpeg;base64,' . $base64Image . '" alt="Alumni Photo" style="width: 400px; height: 300px;">';
            echo '<p class="caption">'.$row['event_caption'].'</p>';
            echo '</div>';
  }
  ?>
</div>
</div>
<h2>Official Meets</h2>
<form action="#" method="post" enctype="multipart/form-data">
    <h3>Upload Official Meet Image</h3>
    <input type="file" name="meetImage">
    <input type="text" name="meetCaption" placeholder="Enter Official Meet Image Caption">
    <input type="submit" name="submitMeet" value="Upload">
  </form>
<div class="image-gallery">
<div class="uploaded-image">
  <?php
  // Retrieve and display the images and captions from the official_meets table
  $resultMeets = mysqli_query($conn, "SELECT * FROM official_meets");
  while ($row = mysqli_fetch_array($resultMeets)) {
      $imageData = $row['meet_image'];
            $base64Image = base64_encode($imageData);
            echo '<div class="image-wrap">';
            echo '<img src="data:image/jpeg;base64,' . $base64Image . '" alt="Alumni Photo" style="width: 400px; height: 300px;">';
            echo '<p class="caption">'.$row['meet_caption'].'</p>';
            echo '</div>';
//    echo '<div>';
//    echo '<img src="data:image/jpeg;base64,'.base64_encode($row['meet_image']).'" />';
//    echo '<p>'.$row['meet_caption'].'</p>';
//    echo '</div>';
  }
  ?>
</div>
    </div>
<div class="foot">
        <h1 style="text-align:center; font-size:40px;color:gray;">Hogwart's Alumni Association</h1>
        <h2 style="text-align:center; font-size:20px;color:whitesmoke;">With You in your Curriculum,</h2>
        <h2 style="text-align:center; font-size:20px;color:whitesmoke;">And With You Beyond your curriculum</h2>
        <h3 style="text-align:center; font-size: 18px;color:gray;">Stay in Touch</h3>
    <span>
        <span><p style="text-align:left; font-size:15px;color:gray;">Designed & Maintained by Batch-13 Sec III-C &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;
        &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;<a style="text-align:right; font-size:15px;color:gray;">&copy All Rights Reserved</a></p></span>
    </span>
    </div>
</body>
</html>
